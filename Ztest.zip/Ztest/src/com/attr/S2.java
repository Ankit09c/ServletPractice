package com.attr;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class S2 extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		int nn1 = Integer.parseInt(req.getParameter("n1"));
		int nn2 = Integer.parseInt(req.getParameter("n2"));

		int p = nn1 * nn2;

		int sum = (int) req.getAttribute("sum");
		
		
		PrintWriter out=resp.getWriter();
		out.print("sum is:--"+sum);
		out.print("Product is:--"+p);

	}

}
