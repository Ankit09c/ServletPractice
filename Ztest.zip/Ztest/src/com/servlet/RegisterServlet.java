package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class RegisterServlet extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");

		PrintWriter out = response.getWriter();
		out.println("<h2>Welcome Register Servlet</h2>");

		String name = req.getParameter("username");
		String password = req.getParameter("password");
		String email = req.getParameter("email");
		String gender = req.getParameter("user_gender");
		String course = req.getParameter("user_course");
		String cond = req.getParameter("condition");

		if (cond != null) {

			if (cond.equals("checked")) {

				out.println("<h2>Name :" + name + "</h2>");
				out.println("<h2>Passsword :" + password + "</h2>");

				out.println("<h2>Email :" + email + "</h2>");
				out.println("<h2>gender :" + gender + "</h2>");
				out.println("<h2>Course :" + course + "</h2>");
				
				RequestDispatcher rd=req.getRequestDispatcher("success");
				rd.forward(req, response);
				
			} else {
				out.println("<h2>You have not accepted terms and condition</h2>");
			}
		} else {
			out.println("<h2>You have not accepted terms and condition</h2>");
			
			RequestDispatcher rd=req.getRequestDispatcher("index.html");
			rd.include(req, response);
		}
	}

}
