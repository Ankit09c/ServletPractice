package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

public class FirstServlet implements Servlet {

	ServletConfig cfg;

	@Override
	public void destroy() {
		// TODO Auto-generated method stub

		System.out.println("Destroy method");

	}

	@Override
	public ServletConfig getServletConfig() {
		// TODO Auto-generated method stub
		return this.cfg;
	}

	@Override
	public String getServletInfo() {
		// TODO Auto-generated method stub
		return "this servlet crated by ankit gupta";
	}

	@Override
	public void init(ServletConfig cfg) throws ServletException {
		// TODO Auto-generated method stub

		this.cfg = cfg;
		System.out.println("Creating Object");

	}

	@Override
	public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("Servicing");
		
		res.setContentType("text/html");
		
		PrintWriter out=res.getWriter();
		out.print("<h1>This is my output</h1>");

	}

}
